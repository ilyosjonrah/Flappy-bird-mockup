# Overview

- A flappy bird mockup to test my JavaScript skills. A bunch of spaghetti code here and there, but I approached how I understood the problem. Could definitely do better.


# Live site
- [Github](https://justinjovert.github.io/Flappy-bird-mockup/)

# Acknowledgments

- Followed the tutorial of [CodeExplained](https://github.com/CodeExplainedRepo/FlappyBird-JavaScript) and other repositories from Github.